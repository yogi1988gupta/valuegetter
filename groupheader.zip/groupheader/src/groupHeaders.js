import React, {Component} from "react";
import './fna.css'
// import { Typography } from '@material-ui/core';


export class GroupHeaders extends Component {    
    constructor(props) {        
        super(props);
        console.log(props);
        this.state = {
            expandState: 'collapsed',
            value: this.props.displayName
        }
        props.columnGroup.getOriginalColumnGroup().addEventListener('expandedChanged', this.syncExpandButtons.bind(this));
    }

    componentDidMount() {
        this.syncExpandButtons();
    }

    expandOrCollapse() {
        let currentState = this.props.columnGroup.getOriginalColumnGroup().isExpanded();
        this.props.setExpanded(!currentState);
    }

    syncExpandButtons() {
        this.setState({
            expandState: this.props.columnGroup.getOriginalColumnGroup().isExpanded() ? 'contracted' : 'expanded'
        });
    }

    render() {
        return (
            <div className="ag-header-group-cell-label">
                <div className="collapsedHeader">{this.props.displayName}</div>
                <div className="iconGroupHeader">
                    <span className={`ag-icon ag-icon-${this.state.expandState}`} onClick={this.expandOrCollapse.bind(this)}></span>
                </div>
                {/* <div className='customExpandButton'>
                    <span class="ag-icon ag-icon-expanded" unselectable="on"></span>
                </div> */}
            </div>
        );
    }
}