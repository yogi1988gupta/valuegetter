import React, { Component } from "react";
import {TextField} from '@material-ui/core';

export class PopupEditor extends Component {
    constructor(props) {
        super(props);
    }
    isPopup(){
        return true;
    }

    render() {
        return (
            <TextField
                multiuline
                rows={6}
                style={{width: '300px'}}
                placeholder="enter your comments"
            />
        );
    }
}