export function getColDefs() {
    return [
        {
            "headerName": "",
            "children": [
                {
                    "headerName": "Client Name",
                    "field": "ClientName",
                    "pinned": "left",
                    "width": 150
                },
                {
                    "headerName": "SalesPerson Name",
                    "field": "SalesPersonName",
                    "pinned": "left",
                    "width": 150
                },
                {
                    "headerName": "Total",
                    "field": "AllTotal",
                    "pinned": "left",
                    "width": 90,
                    valueGetter: function aPlusBValueGetter(params) {
                        let total = 0;
                        const stringToCheck = 'Total'
                        Object.keys(params.data).forEach(function(key, Index) {
                            var x = key.substr(0, stringToCheck.length);
                            if(x===stringToCheck && key.indexOf(stringToCheck+'_')===-1 ) {
                                total += params.data[key];       
                            }
                        }
                        );
                        return total;
                      }
                }
            ]
        },
        {
            "headerName": "Credit",
            "children": [
                {
                    "headerName": "TotalCredit",
                    "field": "TotalCredit",
                    "filter": "agNumberColumnFilter",
                    "width": 125,
                    "valueFormatter": function (params) { 
                                        return '$'+ params.value 
                                    }
                },
                {
                    "headerName": "Investment Grade",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_InvestmentGrade",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_InvestmentGrade",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_InvestmentGrade",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "High Yield",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_HighYield",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_HighYield",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_HighYield",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "ABS",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_ABS",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_ABS",
                            "width": 125
                        },
                        {
                            "headerName": "FY 2019 CV",
                            "field": "Y_CURR_ABS",
                            "width": 125,
                            "editable": true,
                            "cellEditor": "numericCellEditor"
                        }
                    ]
                },
                {
                    "headerName": "Loans",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_Loans",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_Loans",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_Loans",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "MoneyMarket",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_MoneyMarket",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_MoneyMarket",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_MoneyMarket",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "CLO",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_CLO",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_CLO",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_CLO",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "Converties",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_Converties",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_Converties",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_Converties",
                            "width": 125
                        }
                    ]
                }
            ]
        },
        {
            "headerName": "FX",
            "children": [
                {
                    "headerName": "Total FX",
                    "field": "TotalFX",
                    "width": 125
                },
                {
                    "headerName": "G11",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_G11",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_G11",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_G11",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "EM",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_EM",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_EM",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_EM",
                            "width": 125
                        }
                    ]
                }
            ]
        },
        {
            "headerName": "Rates",
            "children": [
                {
                    "headerName": "Total Rates",
                    "field": "TotalRates",
                    "width": 125
                },
                {
                    "headerName": "Rates Derivates",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_RatesDerivates",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_RatesDerivates",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_RatesDerivates",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "Rates Cash",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_RatesCash",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_RatesCash",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_RatesCash",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "Structured Rates",
                    "columnGroupShow": "open",
                    "field": "Total_Structured Rates",
                    "width": 125
                }
            ]
        },
        {
            "headerName": "Municipals",
            "field": "TotalMunicipal",
            "width": 125
        },
        {
            "headerName": "Futures",
            "children": [
                {
                    "headerName": "Total Futures",
                    "field": "TotalFutures",
                    "width": 125
                },
                {
                    "headerName": "Client Clearing",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_ClientClearing",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_ClientClearing",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_ClientClearing",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "Client Execution",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_ClientExecution",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_ClientExecution",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_ClientExecution",
                            "width": 125
                        }
                    ]
                }
            ]
        },
        {
            "headerName": "Commodities",
            "children": [
                {
                    "headerName": "Total Commodities",
                    "field": "TotalCommodities",
                    "width": 125
                },
                {
                    "headerName": "Gas",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_Gas",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_Gas",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_Gas",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "Crude Oil",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_CrudeOil",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_CrudeOil",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_CrudeOil",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "Base Metals",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_BaseMetals",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_BaseMetals",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_BaseMetals",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "Index",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_Index",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_Index",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_Index",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "Precious Metals",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_PreciousMetals",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_PreciousMetals",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_PreciousMetals",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "Power",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_Power",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_Power",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_Power",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "Emmissions",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_Emmissions",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_Emmissions",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_Emmissions",
                            "width": 125
                        }
                    ]
                },
                {
                    "headerName": "Ags",
                    "columnGroupShow": "open",
                    "children": [
                        {
                            "headerName": "Total",
                            "field": "Total_Ags",
                            "width": 125
                        },
                        {
                            "headerName": "YOY",
                            "field": "YOY_Ags",
                            "width": 125
                        },
                        {
                            "headerName": "F 2019 CV",
                            "field": "Y_CURR_Ags",
                            "width": 125
                        }
                    ]
                }
            ]
        },
        {
            "headerName": "401K",
            "field": "Total401K",
            "width": 125
        },
        {
            "headerName": "",
            "children": [
                {
                    "headerName": "Comments",
                    "field": "Comments",
                    "width": 150
                },
                {
                    "headerName": "Coverage",
                    "headerCheckboxSelection": true,
                    "field": "Coverage",
                    "width": 150
                }
            ]
        }
    ]
}